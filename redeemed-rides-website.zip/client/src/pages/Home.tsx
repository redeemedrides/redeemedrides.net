import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Wrench, Heart, Bike, Phone } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Header />
      <div className="min-h-screen flex flex-col pt-20">
        {/* Hero Section */}
      <section className="bg-primary text-primary-foreground py-20">
        <div className="container text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Redeemed Rides
          </h1>
          <p className="text-xl md:text-2xl mb-4 opacity-90">
            Mobile E-Bike Mechanic
          </p>
          <p className="text-lg mb-8 opacity-80 max-w-2xl mx-auto">
            Professional e-bike repair and maintenance that comes to you
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/prices">
              <Button size="lg" variant="secondary">
                View Pricing
              </Button>
            </Link>
            <Link href="/stories">
              <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                Our Impact
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-background">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">
            Why Choose Redeemed Rides?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <MapPin className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">Mobile Service</h3>
                  <p className="text-muted-foreground text-sm">
                    We come to your location—home, office, or anywhere you need us. 
                    No need to transport your e-bike.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Wrench className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">Expert Service</h3>
                  <p className="text-muted-foreground text-sm">
                    Professional e-bike repair and maintenance from experienced 
                    technicians who know e-bikes inside and out.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Heart className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">Give Back</h3>
                  <p className="text-muted-foreground text-sm">
                    5% of all sales go to support homeless individuals and people 
                    in need in our community.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Bike className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-bold text-lg mb-2">All E-Bikes</h3>
                  <p className="text-muted-foreground text-sm">
                    We service all makes and models of e-bikes, from commuter bikes 
                    to cargo bikes and everything in between.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-muted">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold text-xl mb-2">Tune-Ups</h3>
                <p className="text-muted-foreground text-sm mb-4">Starting at $150</p>
                <p className="text-sm">
                  Keep your e-bike running smoothly with our comprehensive tune-up 
                  packages, from basic to complete overhaul.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold text-xl mb-2">Repairs</h3>
                <p className="text-muted-foreground text-sm mb-4">Flat rates for common fixes</p>
                <p className="text-sm">
                  From flat tires to brake adjustments, we handle all common e-bike 
                  repairs with transparent pricing.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <h3 className="font-bold text-xl mb-2">E-Bike Specific</h3>
                <p className="text-muted-foreground text-sm mb-4">Electrical & assembly</p>
                <p className="text-sm">
                  Controller installation, display setup, battery diagnostics, and 
                  new e-bike assembly from the box.
                </p>
              </CardContent>
            </Card>
          </div>
          <div className="text-center mt-8">
            <Link href="/prices">
              <Button size="lg">See Full Pricing Guide</Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container text-center">
          <div className="max-w-3xl mx-auto">
            <Heart className="h-12 w-12 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-6">Riding with Purpose</h2>
            <p className="text-lg mb-8 opacity-90">
              When you choose Redeemed Rides, you're not just getting your e-bike 
              fixed—you're helping us support those in need. 5% of every dollar we 
              earn goes directly to helping homeless individuals and families in our 
              community.
            </p>
            <Link href="/stories">
              <Button size="lg" variant="secondary">
                Read Impact Stories
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-background">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Schedule your mobile e-bike service today and experience the convenience 
            of professional repair at your location.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="tel:+15306132751">
              <Button size="lg" className="gap-2">
                <Phone className="h-5 w-5" />
                Call for Service
              </Button>
            </a>
            <Link href="/feedback">
              <Button size="lg" variant="outline">
                Send Us Feedback
              </Button>
            </Link>
          </div>
        </div>
      </section>
      </div>
      <Footer />
    </>
  );
}
