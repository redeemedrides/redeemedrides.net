import { Link, useLocation } from "wouter";
import { APP_LOGO, APP_TITLE } from "@/const";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

export default function Header() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/prices", label: "Prices" },
    { path: "/stories", label: "Stories & Impact" },
    { path: "/feedback", label: "Feedback" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white shadow-lg border-b border-border"
          : "bg-white/95 backdrop-blur-sm shadow-md"
      }`}
    >
      <div className="container">
        <div className="flex items-center justify-between h-20">
          {/* Logo and Title */}
          <Link href="/">
            <a className="flex items-center gap-3 group">
              <div className="relative">
                <img
                  src={APP_LOGO}
                  alt={APP_TITLE}
                  className="h-14 w-14 transition-transform duration-300 group-hover:scale-110"
                />
              </div>
              <div className="hidden sm:block">
                <div className="font-bold text-xl text-primary transition-colors duration-300 group-hover:text-accent">
                  {APP_TITLE}
                </div>
                <div className="text-xs text-muted-foreground font-medium">
                  Mobile E-Bike Mechanic
                </div>
              </div>
            </a>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-2">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={location === item.path ? "default" : "ghost"}
                  className={`text-sm font-medium transition-all duration-300 ${
                    location === item.path
                      ? "shadow-md"
                      : "hover:bg-primary/10 hover:scale-105"
                  }`}
                >
                  {item.label}
                </Button>
              </Link>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden hover:bg-primary/10 transition-all duration-300 hover:scale-110"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6 text-primary" />
            ) : (
              <Menu className="h-6 w-6 text-primary" />
            )}
          </Button>
        </div>

        {/* Mobile Navigation - Animated Dropdown */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-500 ease-in-out ${
            mobileMenuOpen
              ? "max-h-96 opacity-100 pb-4"
              : "max-h-0 opacity-0"
          }`}
        >
          <nav className="space-y-2 pt-2">
            {navItems.map((item, index) => (
              <Link key={item.path} href={item.path}>
                <div
                  className={`transform transition-all duration-300 ${
                    mobileMenuOpen
                      ? "translate-x-0 opacity-100"
                      : "-translate-x-4 opacity-0"
                  }`}
                  style={{ transitionDelay: `${index * 50}ms` }}
                >
                  <Button
                    variant={location === item.path ? "default" : "ghost"}
                    className={`w-full justify-start text-left transition-all duration-300 ${
                      location === item.path
                        ? "shadow-md"
                        : "hover:bg-primary/10 hover:translate-x-2"
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.label}
                  </Button>
                </div>
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
}
