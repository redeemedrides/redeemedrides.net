import { Mail, Phone, Clock, User } from "lucide-react";
import { APP_TITLE } from "@/const";
import { Card, CardContent } from "@/components/ui/card";

export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-muted to-muted/50 mt-auto border-t border-border">
      {/* Large Contact Section */}
      <div className="container py-16">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4">Contact Us</h2>
          <p className="text-center text-muted-foreground mb-12 text-lg">
            Get in touch with Samuel Flood for professional e-bike service
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {/* Owner Name Card */}
            <Card className="border-2 hover:border-primary transition-all duration-300 hover:shadow-xl">
              <CardContent className="pt-8 pb-8">
                <div className="flex flex-col items-center text-center">
                  <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <User className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-bold text-xl mb-2">Owner & Mechanic</h3>
                  <p className="text-2xl font-bold text-primary">Samuel Flood</p>
                </div>
              </CardContent>
            </Card>

            {/* Email Card */}
            <Card className="border-2 hover:border-primary transition-all duration-300 hover:shadow-xl">
              <CardContent className="pt-8 pb-8">
                <div className="flex flex-col items-center text-center">
                  <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Mail className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-bold text-xl mb-3">Email</h3>
                  <a
                    href="mailto:redeemedridesrepair@gmail.com"
                    className="text-lg font-semibold text-primary hover:text-accent transition-colors duration-300 hover:underline break-all"
                  >
                    redeemedridesrepair@gmail.com
                  </a>
                </div>
              </CardContent>
            </Card>

            {/* Phone Card */}
            <Card className="border-2 hover:border-primary transition-all duration-300 hover:shadow-xl">
              <CardContent className="pt-8 pb-8">
                <div className="flex flex-col items-center text-center">
                  <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Phone className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-bold text-xl mb-3">Phone</h3>
                  <a
                    href="tel:+15306132751"
                    className="text-2xl font-bold text-primary hover:text-accent transition-colors duration-300 hover:underline"
                  >
                    (530) 613-2751
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Hours Card - Full Width */}
          <Card className="border-2 hover:border-primary transition-all duration-300 hover:shadow-xl">
            <CardContent className="pt-8 pb-8">
              <div className="flex flex-col items-center text-center">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <Clock className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-bold text-2xl mb-3">Availability</h3>
                <p className="text-xl font-semibold text-foreground mb-2">
                  Call or Email to Schedule Service
                </p>
                <p className="text-lg text-muted-foreground">
                  Monday - Friday: 12:00 PM - 8:00 PM
                </p>
                <p className="text-sm text-muted-foreground mt-3 max-w-2xl">
                  Service appointments are scheduled after initial contact. Reach out today to discuss your e-bike repair needs!
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="bg-primary/5 border-t border-border">
        <div className="container py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* About */}
            <div>
              <h3 className="font-bold text-lg mb-3">{APP_TITLE}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Professional mobile e-bike repair and maintenance that comes to you.
                Supporting our community, one ride at a time. 5% of all sales go to
                help homeless individuals and people in need.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-bold text-lg mb-3">Quick Links</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <a href="/" className="text-muted-foreground hover:text-primary transition-colors">
                  Home
                </a>
                <a href="/prices" className="text-muted-foreground hover:text-primary transition-colors">
                  Pricing
                </a>
                <a href="/stories" className="text-muted-foreground hover:text-primary transition-colors">
                  Stories & Impact
                </a>
                <a href="/feedback" className="text-muted-foreground hover:text-primary transition-colors">
                  Feedback
                </a>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-border text-center text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} {APP_TITLE}. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
