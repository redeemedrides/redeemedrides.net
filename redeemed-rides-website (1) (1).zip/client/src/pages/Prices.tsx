import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Phone } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Prices() {
  const tuneUpPackages = [
    {
      name: "Basic Tune-Up",
      price: "$150",
      features: [
        "Brake adjustment",
        "Gear adjustment",
        "Tire pressure check",
        "Chain lubrication",
        "Safety inspection",
      ],
    },
    {
      name: "Standard Tune-Up",
      price: "$225",
      features: [
        "Everything in Basic",
        "Wheel truing",
        "Cable replacement",
        "Battery health check",
        "Display diagnostics",
        "Deep cleaning",
      ],
    },
    {
      name: "Complete Overhaul",
      price: "$350",
      features: [
        "Everything in Standard",
        "Full drivetrain service",
        "Bearing inspection & service",
        "Electrical system check",
        "Motor diagnostics",
        "Performance optimization",
      ],
    },
  ];

  const commonRepairs = [
    { service: "Flat Tire Repair", price: "$35" },
    { service: "Tube Replacement", price: "$45" },
    { service: "Brake Pad Replacement", price: "$50" },
    { service: "Chain Replacement", price: "$60" },
    { service: "Derailleur Adjustment", price: "$40" },
    { service: "Wheel Truing", price: "$45" },
  ];

  const eBikeSpecific = [
    { service: "Battery Diagnostics", price: "$75" },
    { service: "Controller Installation", price: "$100" },
    { service: "Display Setup", price: "$60" },
    { service: "Motor Diagnostics", price: "$85" },
    { service: "E-Bike Assembly (from box)", price: "$150" },
    { service: "Electrical Troubleshooting", price: "$90/hr" },
  ];

  return (
    <>
      <Header />
      <div className="min-h-screen flex flex-col pt-32 pb-12">
      <div className="container">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Pricing</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Transparent, flat-rate pricing for all our mobile e-bike services. 
            All prices include travel to your location within our service area.
          </p>
        </div>

        {/* Tune-Up Packages */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Tune-Up Packages</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tuneUpPackages.map((pkg) => (
              <Card key={pkg.name} className="flex flex-col">
                <CardHeader>
                  <CardTitle className="text-2xl">{pkg.name}</CardTitle>
                  <div className="text-3xl font-bold text-primary">{pkg.price}</div>
                </CardHeader>
                <CardContent className="flex-1">
                  <ul className="space-y-3">
                    {pkg.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2">
                        <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Common Repairs */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">Common Repairs</h2>
          <Card className="max-w-3xl mx-auto">
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {commonRepairs.map((repair) => (
                  <div
                    key={repair.service}
                    className="flex justify-between items-center p-3 rounded-lg bg-muted"
                  >
                    <span className="font-medium">{repair.service}</span>
                    <span className="text-primary font-bold">{repair.price}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* E-Bike Specific Services */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-8">
            E-Bike Specific Services
          </h2>
          <Card className="max-w-3xl mx-auto">
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {eBikeSpecific.map((service) => (
                  <div
                    key={service.service}
                    className="flex justify-between items-center p-3 rounded-lg bg-muted"
                  >
                    <span className="font-medium">{service.service}</span>
                    <span className="text-primary font-bold">{service.price}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Additional Info */}
        <section className="mb-12">
          <Card className="max-w-3xl mx-auto bg-muted">
            <CardContent className="pt-6">
              <h3 className="font-bold text-lg mb-4">Important Information</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• All prices include mobile service within our service area</li>
                <li>• Parts are additional and quoted before work begins</li>
                <li>• Custom jobs quoted on a case-by-case basis</li>
                <li>• 5% of all sales support homeless individuals in our community</li>
                <li>• Payment accepted: Cash, Venmo, Zelle</li>
              </ul>
            </CardContent>
          </Card>
        </section>

        {/* CTA */}
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4">Ready to Schedule Service?</h3>
          <p className="text-muted-foreground mb-6">
            Call or email us to set up your appointment
          </p>
          <a href="tel:+15306132751">
            <Button size="lg" className="gap-2">
              <Phone className="h-5 w-5" />
              (530) 613-2751
            </Button>
          </a>
        </div>
      </div>
      </div>
      <Footer />
    </>
  );
}
