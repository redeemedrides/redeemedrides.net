import { Card, CardContent } from "@/components/ui/card";
import { Heart } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function Stories() {
  return (
    <>
      <Header />
      <div className="min-h-screen flex flex-col pt-32 pb-12">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Stories & Impact</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Making a Difference, One Ride at a Time
          </p>
        </div>

        {/* Our Commitment */}
        <section className="mb-16">
          <Card className="max-w-4xl mx-auto">
            <CardContent className="pt-8">
              <div className="text-center mb-8">
                <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-4">Our Commitment</h2>
                <p className="text-lg font-semibold text-primary mb-4">
                  5% of all sales go to homeless and people in need
                </p>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                At Redeemed Rides, we believe in giving back to the community. 
                Every service you purchase helps us support those who need it most. 
                Through our partnership with local organizations, we provide essential 
                services, meals, and support to homeless individuals and families in need. 
                We're committed to making a real difference by dedicating 5% of every 
                sale to those who need it most.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Impact Statistics */}
        <section className="mb-16">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8">Our Impact</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="pt-8 text-center">
                  <div className="text-4xl font-bold text-primary mb-2">2</div>
                  <div className="text-muted-foreground">People Helped</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-8 text-center">
                  <div className="text-4xl font-bold text-muted-foreground mb-2">—</div>
                  <div className="text-muted-foreground">Donated to Date</div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-8 text-center">
                  <div className="text-4xl font-bold text-muted-foreground mb-2">—</div>
                  <div className="text-muted-foreground">E-Bikes Serviced</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Customer Stories Section - Empty for now */}
        <section className="mb-16">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8">Customer Stories</h2>
            <Card>
              <CardContent className="pt-8 text-center">
                <p className="text-muted-foreground">
                  We're just getting started! Check back soon for stories from our 
                  customers and the people we've helped in our community.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Closing Message */}
        <section>
          <Card className="max-w-4xl mx-auto bg-primary text-primary-foreground">
            <CardContent className="pt-8 text-center">
              <h3 className="text-2xl font-bold mb-4">Your Service Makes a Difference</h3>
              <p className="leading-relaxed opacity-90">
                Every time you choose Redeemed Rides for your e-bike maintenance and 
                repair needs, you're not just getting professional service—you're 
                contributing to a movement that supports those in need. Together, we 
                can make our community stronger, one ride at a time.
              </p>
              <p className="mt-6 font-semibold">
                Thank you for being part of our mission to serve and give back.
              </p>
            </CardContent>
          </Card>
        </section>
      </div>
      </div>
      <Footer />
    </>
  );
}
